#------#
DEV HUD
#------#

Important command list

/trigger dev_hud
    ∟ initializes the datapack

/trigger dev_hud_menu
    ∟ Displays the menu that allows you to configure the datapack

/trigger dev_hud_uninstall
    ∟ Uninstall the datapack by removing all scoreboards and tags